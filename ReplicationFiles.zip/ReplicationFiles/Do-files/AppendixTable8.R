#######################################################################################################
rm(list=ls())
#Chung and olivares (2020);
library(readstata13)
library(RATest)

#Full Cost
SCLB_data<- as.data.frame(read.dta13("DataSCLB.dta"));

pt.GoF<-PT.Khmaladze.fit(SCLB_data$EL_EGRA_PCA_Index[SCLB_data$Study_Arm==2],SCLB_data$EL_EGRA_PCA_Index[SCLB_data$Study_Arm==0],n.perm = 999)
summary(pt.GoF)
FC <- c(pt.GoF$T.obs,pt.GoF$cv,pt.GoF$pvalue)

#Reduced Cost
SCLB_data<- as.data.frame(read.dta13("DataSCLB.dta"));
pt.GoF<-PT.Khmaladze.fit(SCLB_data$EL_EGRA_PCA_Index[SCLB_data$Study_Arm==1],SCLB_data$EL_EGRA_PCA_Index[SCLB_data$Study_Arm==0],n.perm = 999)
ummary(pt.GoF)
RC <- c(pt.GoF$T.obs,pt.GoF$cv,pt.GoF$pvalue)

results <- rbind(FC,RC)

write.dta(data.frame(results),"Output/AppendixTable8.dta")